#!/usr/bin/env python
import Classes_Gillespie as Classy
import Functions_Gillespie as Gill
import numpy as np
import matplotlib.pyplot as plt
import os
from pathlib import Path
import pickle as pkl
import time as t
import datetime as dt
import multiprocessing as mp
safeProcessors = max(1, int(mp.cpu_count() * .5) - 1)


# Function Definitions
def run_pipeline(gillespie_parameters, processing_parameters, work_path, storage_path):
    [reaction_list, initial_state, switching_rate, system_size, markov_state] = Initialize_Reactions(gillespie_parameters)
    [number_of_hits, thresh] = processing_parameters
    signal = Gill.gillespie_switching_thresholding(reaction_list, number_of_hits, initial_state, switching_rate, markov_state, threshold=thresh)
    archive_signal(signal, work_path + '{}transitions.pkl'.format(gillespie_parameters), storage_path)


def archive_signal(signal, file_name, storage):
    os.system("touch " + file_name.replace(" ",r"\ "))
    with open(file_name, 'wb') as handle:
        pkl.dump(signal, handle, protocol=pkl.HIGHEST_PROTOCOL)
    os.system("gzip {} ;".format("'" + file_name + "'") +
              " mv {} {} &".format("'" + file_name + ".gz'", storage.replace(" ",r"\ ")))


def get_files(path, string="signal"):
    only_files = [f for f in os.listdir(path) if os.path.isfile(os.path.join(path, f))]
    only_files = [f for f in only_files if string in f]
    return only_files


def Initialize_Reactions(parameters):
    [mu, cv, state, rate] = parameters
    a = 15.8202
    gamma = np.log(2)
    beta = 2 * gamma * a
    s = 10
    k = s ** 3 / (2 * a - s)
    exponent = 2
    root_k = k ** (1/exponent) # k gets hit with an exponent in decreasing_hill_propensity
    initial_vector = np.array([30,2], dtype=int)

    dilution0 = Classy.Reaction(np.array([-1,0], dtype=int), [0], 'mobius_propensity', [0, gamma, 1, 0], 1, [[0],[0]])
    dilution1 = Classy.Reaction(np.array([0,-1], dtype=int), [1], 'mobius_propensity', [0, gamma, 1, 0], 1, [[0],[0]])
    production0 = Classy.Reaction(np.array([1,0], dtype=int), [1], 'decreasing_hill_propensity', [beta, root_k, exponent, 1], 'gamma_distribution', [[mu,mu*cv],[mu,mu*cv]])
    production1 = Classy.Reaction(np.array([0,1], dtype=int), [0], 'decreasing_hill_propensity', [beta, root_k, exponent, 1], 'gamma_distribution', [[mu,mu*cv],[mu,mu*cv]])
    reaction_list = [dilution0, dilution1, production0, production1]
    return [reaction_list, initial_vector, rate, 1, state]


'''
[reaction_list, initial_state, system_size] = Initialize_Reactions([2, .5])
signal, _ = Gill.gillespie_switching(reaction_list, 5000, np.array([0], dtype=int), .01)
times = [sig["time"] for sig in signal]
states = [sig["state"] for sig in signal]
markovs = [sig["markov state"] for sig in signal]
trans_times = [sig["time"] for sig in signal if sig["transition"]]
trans_states = [sig["state"] for sig in signal if sig["transition"]]
plt.plot(times,states)
plt.scatter(trans_times,trans_states)
plt.scatter(times,markovs)
plt.show()
'''

if __name__ == '__main__':
    with mp.Pool(safeProcessors) as pool2:
        mu_range = [4]
        cv_range = list(np.round(np.linspace(0,1.2,31),2))
        rate_range = [2**(-20)] #list(2 ** np.linspace(0,8,9))
        state_range = [0,1]
        number_of_hits = 201
        batches = 25
        thresh = 6
        paths_to_raw_data = ["2025-4-27/gamma_distributed/batch{}/".format(batch) for batch in range(batches)] ### edit to today's date and current batch
        paths_to_storage = ["/home/spcampbe/servers/storage/data_storage/" + path for path in paths_to_raw_data]
        for batch in range(batches):
            Path(paths_to_raw_data[batch]).mkdir(parents=True, exist_ok=True)
            Path(paths_to_storage[batch]).mkdir(parents=True, exist_ok=True)

        parameter_sets = Gill.list_for_parallelization([mu_range, cv_range, state_range, rate_range])
        pool_data = []
        for batch in range(batches):
            pool_data = pool_data + [{"parameters" : parameter_set, "batch" : batch} for parameter_set in parameter_sets]

        for batch in range(batches):
            existing_files = [f for f in get_files(paths_to_storage[batch], "transitions")
                              if os.path.getsize(os.path.join(paths_to_storage[batch], f)) > 1]
            for file in existing_files:
                index_extract = [(pool["batch"] == batch) for pool in pool_data]
                for index in [i for i,x in enumerate(index_extract) if x]:
                    if str(pool_data[index]["parameters"]) in file:
                        del pool_data[index]
                        break
        print(set([tuple(pool["parameters"]) for pool in pool_data]))
        try:
            start_time = t.time()
            pool2.starmap(run_pipeline, [(pool["parameters"], [number_of_hits, thresh],
                                          paths_to_raw_data[pool["batch"]], paths_to_storage[pool["batch"]]) for pool in pool_data])
            print(t.time()-start_time)
        finally:
            pool2.close()
            pool2.join()

